class Thumbnail{
  String videoPath;
  String thumbnailPath;

  Thumbnail({
    required this.thumbnailPath,
    required this.videoPath,
  });
}